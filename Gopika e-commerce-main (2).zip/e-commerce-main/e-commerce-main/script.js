const products = [
  { id: 1, name: 'HP Victus Laptop', category: 'electronics', price: 999, image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8', description: 'High-performance gaming laptop.' },
  { id: 2, name: 'Coffee Maker', category: 'appliances', price: 120, image: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=800&q=80', description: 'Automatic coffee maker for fresh brews every morning.' },
  { id: 3, name: 'T-Shirt', category: 'clothing', price: 25, image: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27', description: 'Soft cotton tee for daily comfort.' },
  { id: 4, name: 'Smartphone', category: 'electronics', price: 799, image: 'https://images.unsplash.com/photo-1591337676887-a217a6970a8a', description: 'Feature-rich smartphone with HD camera.' },
  { id: 5, name: 'Sneakers', category: 'footwear', price: 90, image: 'https://images.unsplash.com/photo-1552346154-21d32810aba3', description: 'Comfortable and stylish sneakers.' },
  { id: 6, name: 'Wrist Watch', category: 'accessories', price: 120, image: 'https://images.unsplash.com/photo-1523170335258-f5ed11844a49', description: 'Elegant wristwatch for any occasion.' },
  { id: 7, name: 'Lipstick', category: 'beauty', price: 30, image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=800&q=80', description: 'Long-lasting matte lipstick with rich color payoff.' },
  { id: 8, name: 'Yoga Mat', category: 'health', price: 40, image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3Ui-OvH7J6U5x7Y-vVyDWK74_qGM0zlq-lw&s', description: 'Non-slip mat for daily workouts.' },
  { id: 9, name: 'Gaming Chair', category: 'furniture', price: 250, image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQO3L2xxvs3smyho88NSwl-FztOerIF_5y2Ng&s', description: 'Ergonomic gaming chair for comfort during long sessions.' },
  { id: 10, name: 'Backpack', category: 'accessories', price: 55, image: 'https://m.media-amazon.com/images/I/61hUNpTUrbL._AC_UY1100_.jpg',  description: 'Durable backpack with multiple compartments for travel.' },

  
];


const categories = [...new Set(products.map(p => p.category))];
let currentCategory = null;
let filteredProducts = [...products];
let cart = [];

const categoryList = document.querySelector('.category-list');
const productsGrid = document.querySelector('.products-grid');
const cartCount = document.getElementById('cart-count');
const cartModal = document.getElementById('cart-modal');
const cartItems = document.getElementById('cart-items');
const cartTotal = document.getElementById('cart-total');
const viewCartBtn = document.getElementById('view-cart');
const closeCartBtn = document.getElementById('close-cart');
const applyFiltersBtn = document.getElementById('apply-filters');
const clearFiltersBtn = document.getElementById('clear-filters');

function init() {
  renderCategories();
  renderProducts();
}

function renderCategories() {
  categoryList.innerHTML = '';
  categories.forEach(cat => {
    const btn = document.createElement('button');
    btn.textContent = cat.charAt(0).toUpperCase() + cat.slice(1);
    btn.addEventListener('click', () => filterByCategory(cat));
    categoryList.appendChild(btn);
  });
}

function renderProducts() {
  productsGrid.innerHTML = '';
  filteredProducts.forEach(p => {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
      <img src="${p.image}" alt="${p.name}">
      <div class="info">
        <h3>${p.name}</h3>
        <p>${p.description}</p>
        <span>$${p.price}</span>
        <button class="add-to-cart" data-id="${p.id}">Add to Cart</button>
      </div>
    `;
    productsGrid.appendChild(card);
  });

  document.querySelectorAll('.add-to-cart').forEach(btn => {
    btn.addEventListener('click', () => addToCart(parseInt(btn.dataset.id)));
  });
}

function filterByCategory(cat) {
  currentCategory = cat;
  filteredProducts = products.filter(p => p.category === cat);
  renderProducts();
}

function addToCart(id) {
  const product = products.find(p => p.id === id);
  cart.push(product);
  updateCartCount();
}

function updateCartCount() {
  cartCount.textContent = cart.length;
}

function showCart() {
  cartItems.innerHTML = '';
  let total = 0;
  cart.forEach((item, index) => {
    total += item.price;
    const div = document.createElement('div');
    div.className = 'cart-item';
    div.innerHTML = `
      <span>${item.name}</span>
      <span>$${item.price}</span>
      <button onclick="removeFromCart(${index})">✖</button>
    `;
    cartItems.appendChild(div);
  });
  cartTotal.textContent = total.toFixed(2);
  cartModal.classList.remove('hidden');
}

function removeFromCart(index) {
  cart.splice(index, 1);
  updateCartCount();
  showCart();
}

document.getElementById('close-cart').addEventListener('click', () => {
  cartModal.classList.add('hidden');
});
document.getElementById('view-cart').addEventListener('click', showCart);

document.addEventListener('DOMContentLoaded', init);
